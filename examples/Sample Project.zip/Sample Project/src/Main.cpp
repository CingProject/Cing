#include "Vision.h"

CREATE_APPLICATION( "Vision Demo" );


void setup()
{

}

void draw()
{
}

void end()
{
}

void mousePressed()
{
}

void keyPressed()
{
}